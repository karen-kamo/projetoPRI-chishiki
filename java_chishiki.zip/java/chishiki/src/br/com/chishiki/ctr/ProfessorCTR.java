package br.com.chishiki.ctr;

import java.sql.ResultSet;
import br.com.chishiki.dto.ProfessorDTO;
import br.com.chishiki.dao.ProfessorDAO;
import br.com.chishiki.dao.ConexaoDAO;

public class ProfessorCTR {
    ProfessorDAO professorDAO = new ProfessorDAO();
    
    public ProfessorCTR(){
        
    }
    public String inserirProfessor(ProfessorDTO professorDTO){
        try{
            if(professorDAO.inserirProfessor(professorDTO)){
                return "Professor cadastrado com sucesso!";
            } else{
                return "Professor não cadastrado!";
            }
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            return "Professor não cadastrado!";
        }
    }
    
    public String alterarProfessor(ProfessorDTO professorDTO){
        try{
            if(professorDAO.alterarProfessor(professorDTO)){
                return "Professor alterado com sucesso!";
            } else{
                return "Professor não alterado!";
            }
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            return "Professor não cadastrado!";
        }
    }
    
    public String excluirProfessor(ProfessorDTO professorDTO){
        try{
            if(professorDAO.excluirProfessor(professorDTO)){
                return "Professor excluído com sucesso!";
            } else{
                return "Professor não excluído!";
            }
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            return "Professor não excluído!";
        }
    }
    
    public ResultSet consultarProfessor(ProfessorDTO professorDTO){
        ResultSet rs = null;
        rs = professorDAO.consultarProfessor(professorDTO);
        return rs;
    }
    
    public void CloseDB(){
        ConexaoDAO.CloseDB();
    }
    
}
