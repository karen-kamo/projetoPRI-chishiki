
package br.com.chishiki.ctr;

import java.sql.ResultSet;
import br.com.chishiki.dto.AlunoDTO;
import br.com.chishiki.dao.AlunoDAO;
import br.com.chishiki.dao.ConexaoDAO;

public class AlunoCTR {
    AlunoDAO alunoDAO = new AlunoDAO();
    
    public AlunoCTR(){
    }
    
    public String inserirAluno(AlunoDTO alunoDTO){
        try{
            if (alunoDAO.inserirAluno(alunoDTO)){
                return "Aluno cadastrado com sucesso!";
            } else{
                return "Aluno não cadastrado!";
            }
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            return "Aluno não cadastrado";
        }
    }
    
    public String alterarAluno(AlunoDTO alunoDTO){
        try{
            if(alunoDAO.alterarAluno(alunoDTO)){
                return "Aluno não alterado!" ;
            } else{
                return "Aluno alterado com sucesso!";
            }
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            return "Aluno não alterado!";
        }
    }
    
    public String excluirAluno(AlunoDTO alunoDTO){
        try{
            if (alunoDAO.excluirAluno(alunoDTO)){
                return "Aluno excluído com sucesso!";
            } else{
                return "Aluno não excluído!";
            }
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            return "Aluno nao excluído";
        }
    }
    
    public ResultSet consultarAluno(AlunoDTO alunoDTO){
        ResultSet rs = null;
        rs = alunoDAO.consultarAluno(alunoDTO);
        return rs;
    }
    
    public void CloseDB(){
        ConexaoDAO.CloseDB();
    }
}
