
package br.com.chishiki.ctr;

import java.sql.*;
import br.com.chishiki.dto.AdministradorDTO;
import br.com.chishiki.dao.AdministradorDAO;
import br.com.chishiki.dao.ConexaoDAO;

public class AdministradorCTR {
    AdministradorDAO administradorDAO = new AdministradorDAO();
    
    public AdministradorCTR(){
        
    }
    
     public int logarAdministrador(AdministradorDTO administradorDTO) {
        
        return administradorDAO.logarAdministrador(administradorDTO);

    }
     
     public void CloseDB() {
        ConexaoDAO.CloseDB();
    }
}
