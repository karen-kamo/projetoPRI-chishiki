package br.com.chishiki.dao;

import br.com.chishiki.dto.ProfessorDTO;
import java.sql.*;

public class ProfessorDAO {
    public ProfessorDAO(){
    }
    
    private ResultSet rs = null;
    private Statement stmt = null;
    
    public boolean inserirProfessor(ProfessorDTO professorDTO){
        try{
            ConexaoDAO.ConectDB();
            stmt = ConexaoDAO.con.createStatement();
            String comando = "Insert into professor (nome_prof, email_prof, senha_prof, disciplina_prof) values ( "
                    + "'" + professorDTO.getNome_prof() + "', "
                    + "'" + professorDTO.getEmail_prof() + "', "
                    + "'" + professorDTO.getSenha_prof() + "', "
                    + "'" + professorDTO.getDisciplina_prof() + "') ";
            
            stmt.execute(comando.toUpperCase());
            ConexaoDAO.con.commit();
            stmt.close();
            return true;
        }
        catch(SQLException e){
            System.out.println(e.getMessage());
            return false;
        }
        finally{
            ConexaoDAO.CloseDB();
        }
    }
    
    public boolean excluirProfessor(ProfessorDTO professorDTO){
        try{
            ConexaoDAO.ConectDB();
            stmt = ConexaoDAO.con.createStatement();
            String comando = "Delete from professor where id_prof = " + professorDTO.getId_prof();
            
            stmt.execute(comando);
            ConexaoDAO.con.commit();
            stmt.close();
            return true;
        }
        catch(SQLException e){
            System.out.println(e.getMessage());
            return false;
        }
        finally{
            ConexaoDAO.CloseDB();
        }
    }
    
    public boolean alterarProfessor(ProfessorDTO professorDTO){
        try{
            ConexaoDAO.ConectDB();
            stmt = ConexaoDAO.con.createStatement();
            String comando = "Update professor set "
                    + "nome_prof = '" + professorDTO.getNome_prof() + "', "
                    + "email_prof = '" + professorDTO.getEmail_prof() + "', "
                    + "senha_prof = '" + professorDTO.getSenha_prof() + "', "
                    + "disciplina_prof = '" + professorDTO.getDisciplina_prof() + "' "
                    + "where id_prof = " + professorDTO.getId_prof();
            
            stmt.execute(comando.toUpperCase());
            ConexaoDAO.con.commit();
            stmt.close();
            return true;
        }
        catch(SQLException e){
            System.out.println(e.getMessage());
            return false;
        }
        finally{
            ConexaoDAO.CloseDB();
        }
        
    }
    
    public ResultSet consultarProfessor(ProfessorDTO professorDTO) {
        try {
            ConexaoDAO.ConectDB();
            stmt = ConexaoDAO.con.createStatement();
            String comando = "";

            comando = "Select * from professor "
                    + "where nome_prof like '%" + professorDTO.getNome_prof() + "%'";

            rs = stmt.executeQuery(comando.toUpperCase());
            return rs;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return rs;
        }
    }
}
