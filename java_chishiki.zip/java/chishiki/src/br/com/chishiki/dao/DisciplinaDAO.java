package br.com.chishiki.dao;

import br.com.chishiki.dto.DisciplinaDTO;
import java.sql.*;

public class DisciplinaDAO {
    public DisciplinaDAO(){
    }
    
    private ResultSet rs = null;
    private Statement stmt = null;
    
    public boolean inserirDisciplina(DisciplinaDTO disciplinaDTO){
        try{
            ConexaoDAO.ConectDB();
            stmt = ConexaoDAO.con.createStatement();
            String comando = "Insert into disciplina (nome_disc, area_disc) values ("
                    + "'" + disciplinaDTO.getNome_disc() + "', "
                    + "'" + disciplinaDTO.getArea_disc() + "') ";
            
            stmt.execute(comando.toUpperCase());
            ConexaoDAO.con.commit();
            stmt.close();
            return true;
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            return false;
        }
        finally{
            ConexaoDAO.CloseDB();
        }
    }
    
    public boolean excluirDisciplina(DisciplinaDTO disciplinaDTO){
        try{
            ConexaoDAO.ConectDB();
            stmt = ConexaoDAO.con.createStatement();
            String comando = "Delete from disciplina where id_disc = " + disciplinaDTO.getId_disc();
            
            stmt.execute(comando);
            ConexaoDAO.con.commit();
            stmt.close();
            return true;
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            return false;
        }
        finally{
            ConexaoDAO.CloseDB();
        }
    }
    
    public boolean alterarDisciplina(DisciplinaDTO disciplinaDTO){
        try{
            ConexaoDAO.ConectDB();
            stmt = ConexaoDAO.con.createStatement();
            String comando = "Update disciplina set "
                    + "nome_disc = '" + disciplinaDTO.getNome_disc() + "', "
                    + "area_disc = '" + disciplinaDTO.getArea_disc() + "' "
                    + "where id_disc = " + disciplinaDTO.getId_disc();
            stmt.execute(comando.toUpperCase());
            ConexaoDAO.con.commit();
            stmt.close();
            return false;
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            return false;
        }
        finally{
            ConexaoDAO.CloseDB();
        }
    }
    public ResultSet consultarDisciplina(DisciplinaDTO disciplinaDTO) {
        try {
            ConexaoDAO.ConectDB();
            stmt = ConexaoDAO.con.createStatement();
            String comando = "";

            comando = "Select * from disciplina "
                    + "where nome_disc like '%" + disciplinaDTO.getNome_disc() + "%'";

            rs = stmt.executeQuery(comando);
            return rs;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return rs;
        }
    }
}
