
package br.com.chishiki.dao;

import br.com.chishiki.dto.AdministradorDTO;
import java.sql.*;

public class AdministradorDAO {
    public AdministradorDAO(){
    }
    
    private ResultSet rs = null;
    private Statement stmt = null;
    
     public int logarAdministrador(AdministradorDTO administradorDTO) {
        try {
            //Chama o metodo que esta na classe ConexaoDAO para abrir o banco de dados
            ConexaoDAO.ConectDB();
            //Cria o Statement que responsavel por executar alguma coisa no banco de dados
            stmt = ConexaoDAO.con.createStatement();
            //Comando SQL que sera executado no banco de dados
            String comando = "Select id_admin " +
                             "from Administrador " + 
                             "where email_admin = '" + administradorDTO.getEmail_admin()+ "'" +
                             " and senha_admin = '" + administradorDTO.getSenha_admin() + "'";

            //Executa o comando SQL no banco de Dados
            rs = null;
            rs = stmt.executeQuery(comando);
            if(rs.next()){
                return rs.getInt("id_admin");
            }
            else{
                return 0;
            }
                
        } //Caso tenha algum erro no codigo acima é enviado uma mensagem no console com o que esta acontecendo.
        catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
        finally{
            ConexaoDAO.CloseDB();
        }
    }
}
