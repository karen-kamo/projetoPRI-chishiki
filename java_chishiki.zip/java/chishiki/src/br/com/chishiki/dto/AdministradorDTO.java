
package br.com.chishiki.dto;

public class AdministradorDTO {
    private int id_admin;
    private String email_admin, senha_admin;

    public AdministradorDTO(){
        
    }
    
    public int getId_admin() {
        return id_admin;
    }

    public void setId_admin(int id_admin) {
        this.id_admin = id_admin;
    }

    public String getEmail_admin() {
        return email_admin;
    }

    public void setEmail_admin(String email_admin) {
        this.email_admin = email_admin;
    }

    public String getSenha_admin() {
        return senha_admin;
    }

    public void setSenha_admin(String senha_admin) {
        this.senha_admin = senha_admin;
    }
}
