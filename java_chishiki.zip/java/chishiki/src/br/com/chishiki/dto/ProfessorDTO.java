
package br.com.chishiki.dto;


public class ProfessorDTO {
    private int id_prof;
    private String nome_prof, email_prof, senha_prof, disciplina_prof;

    public ProfessorDTO(){
        
    }
    
    public int getId_prof() {
        return id_prof;
    }

    public void setId_prof(int id_prof) {
        this.id_prof = id_prof;
    }

    public String getNome_prof() {
        return nome_prof;
    }

    public void setNome_prof(String nome_prof) {
        this.nome_prof = nome_prof;
    }

    public String getEmail_prof() {
        return email_prof;
    }

    public void setEmail_prof(String email_prof) {
        this.email_prof = email_prof;
    }

    public String getSenha_prof() {
        return senha_prof;
    }

    public void setSenha_prof(String senha_prof) {
        this.senha_prof = senha_prof;
    }
    
    public String getDisciplina_prof() {
        return disciplina_prof;
    }

    public void setDisciplina_prof(String disciplina_prof) {
        this.disciplina_prof = disciplina_prof;
    }
}
