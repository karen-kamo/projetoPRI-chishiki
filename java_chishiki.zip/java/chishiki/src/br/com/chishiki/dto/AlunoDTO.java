package br.com.chishiki.dto;


public class AlunoDTO {
    private int id_alu;
    private String nome_alu, email_alu, senha_alu, curso_alu;
    
    public AlunoDTO(){
        
    }

    public int getId_alu() {
        return id_alu;
    }

    public void setId_alu(int id_alu) {
        this.id_alu = id_alu;
    }

    public String getNome_alu() {
        return nome_alu;
    }

    public void setNome_alu(String nome_alu) {
        this.nome_alu = nome_alu;
    }

    public String getEmail_alu() {
        return email_alu;
    }

    public void setEmail_alu(String email_alu) {
        this.email_alu = email_alu;
    }

    public String getSenha_alu() {
        return senha_alu;
    }

    public void setSenha_alu(String senha_alu) {
        this.senha_alu = senha_alu;
    }

    public String getCurso_alu() {
        return curso_alu;
    }

    public void setCurso_alu(String curso_alu) {
        this.curso_alu = curso_alu;
    }
    
}
