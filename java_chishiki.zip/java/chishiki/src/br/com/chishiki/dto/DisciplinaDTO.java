
package br.com.chishiki.dto;


public class DisciplinaDTO {
   private int id_disc;
   private String nome_disc, area_disc;

   public DisciplinaDTO(){
       
   }
   
    public int getId_disc() {
        return id_disc;
    }

    public void setId_disc(int id_disc) {
        this.id_disc = id_disc;
    }

    public String getNome_disc() {
        return nome_disc;
    }

    public void setNome_disc(String nome_disc) {
        this.nome_disc = nome_disc;
    }
    
    public String getArea_disc() {
        return area_disc;
    }

    public void setArea_disc(String area_disc) {
        this.area_disc = area_disc;
    }

}
