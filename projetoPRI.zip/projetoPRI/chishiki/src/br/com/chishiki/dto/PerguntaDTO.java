
package br.com.chishiki.dto;


public class PerguntaDTO {
   private int id_perg;
   private String conteudo_perg;

    public int getId_perg() {
        return id_perg;
    }

    public void setId_perg(int id_perg) {
        this.id_perg = id_perg;
    }

    public String getConteudo_perg() {
        return conteudo_perg;
    }

    public void setConteudo_perg(String conteudo_perg) {
        this.conteudo_perg = conteudo_perg;
    }
}
