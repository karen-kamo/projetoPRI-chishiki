
package br.com.chishiki.dto;


public class DisciplinaDTO {
   private int id_disc;
   private String nome_disc, curso_disc;

    public int getId_disc() {
        return id_disc;
    }

    public void setId_disc(int id_disc) {
        this.id_disc = id_disc;
    }

    public String getNome_disc() {
        return nome_disc;
    }

    public void setNome_disc(String nome_disc) {
        this.nome_disc = nome_disc;
    }

    public String getCurso_disc() {
        return curso_disc;
    }

    public void setCurso_disc(String curso_disc) {
        this.curso_disc = curso_disc;
    }
}
