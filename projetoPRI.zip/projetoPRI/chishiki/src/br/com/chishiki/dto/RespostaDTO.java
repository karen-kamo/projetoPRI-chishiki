
package br.com.chishiki.dto;


public class RespostaDTO {
   private int id_resp;
   private String conteudo_resp;

    public int getId_resp() {
        return id_resp;
    }

    public void setId_resp(int id_resp) {
        this.id_resp = id_resp;
    }

    public String getConteudo_resp() {
        return conteudo_resp;
    }

    public void setConteudo_resp(String conteudo_resp) {
        this.conteudo_resp = conteudo_resp;
    }
}
