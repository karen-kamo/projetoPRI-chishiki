package br.com.chishiki.dao;

import br.com.chishiki.dto.DisciplinaDTO;
import java.sql.*;

public class DisciplinaDAO {
    public DisciplinaDAO(){
    }
    
    private ResultSet rs = null;
    private Statement stmt = null;
    
    public boolean inserirDisciplina(DisciplinaDTO disciplinaDTO){
        try{
            ConexaoDAO.ConectDB();
            stmt = ConexaoDAO.con.createStatement();
            String comando = "Insert into Disciplina (nome_disc, curso_disc) values ("
                    + "'" + disciplinaDTO.getNome_disc() + "', "
                    + "'" + disciplinaDTO.getCurso_disc() + ") ";
            
            stmt.execute(comando);
            ConexaoDAO.con.commit();
            stmt.close();
            return true;
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            return false;
        }
        finally{
            ConexaoDAO.CloseDB();
        }
    }
    
    public boolean excluirDisciplina(DisciplinaDTO disciplinaDTO){
        try{
            ConexaoDAO.ConectDB();
            stmt = ConexaoDAO.con.createStatement();
            String comando = "Delete from Disciplina where id_disc = " + disciplinaDTO.getId_disc();
            stmt.execute(comando);
            ConexaoDAO.con.commit();
            stmt.close();
            return true;
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            return false;
        }
        finally{
            ConexaoDAO.CloseDB();
        }
    }
    
    public boolean alterarDisciplina(DisciplinaDTO disciplinaDTO){
        try{
            ConexaoDAO.ConectDB();
            stmt = ConexaoDAO.con.createStatement();
            String comando = "Update Disciplina set "
                    + "nome_disc = '" + disciplinaDTO.getNome_disc() + "', "
                    + "curso_disc = '" + disciplinaDTO.getCurso_disc() + "' "
                    + "where id_disc = " + disciplinaDTO.getId_disc();
            stmt.execute(comando);
            ConexaoDAO.con.commit();
            stmt.close();
            return true;
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            return false;
        }
        finally{
            ConexaoDAO.CloseDB();
        }
    }
    public ResultSet consultarDisciplina(DisciplinaDTO disciplinaDTO, int opcao){
        try{
            ConexaoDAO.ConectDB();
            stmt = ConexaoDAO.con.createStatement();
            String comando = "";
            switch (opcao){
                case 1: 
                    comando = "Select d.* "+
                            "from Disciplina d "+
                            "where nome_disc like '" + disciplinaDTO.getNome_disc() + "%' " +
                            "order by d.nome_disc";
                break;
                case 2:
                    comando = "Select d.* "+
                            "from Disciplina d " +
                            "where curso_disc like '" + disciplinaDTO.getCurso_disc() + "%' " +
                            "order by d.curso_disc";
                break;
                case 3:
                    comando = "Select d.* "+
                            "from Disciplina d "+
                            "where d.id_disc = " + disciplinaDTO.getId_disc();
                break;
            }
            rs = stmt.executeQuery(comando);
            return rs;
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            return rs;
        }
    }
}
