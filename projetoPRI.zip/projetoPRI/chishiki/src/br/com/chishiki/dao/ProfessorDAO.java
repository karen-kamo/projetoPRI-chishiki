package br.com.chishiki.dao;

import br.com.chishiki.dto.ProfessorDTO;
import java.sql.*;

public class ProfessorDAO {
    public ProfessorDAO(){
    }
    
    private ResultSet rs = null;
    private Statement stmt = null;
    
    public boolean inserirProfessor(ProfessorDTO professorDTO){
        try{
            ConexaoDAO.ConectDB();
            stmt = ConexaoDAO.con.createStatement();
            String comando = "Insert into Professor (nome_prof, email_prof, senha_prof) values ( "
                    + "'" + professorDTO.getNome_prof() + "', "
                    + "'" + professorDTO.getEmail_prof() + "', "
                    + "'" + professorDTO.getSenha_prof() + "') ";
            
            stmt.execute(comando);
            ConexaoDAO.con.commit();
            stmt.close();
            return true;
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            return false;
        }
        finally{
            ConexaoDAO.CloseDB();
        }
    }
    
    public boolean excluirProfessor(ProfessorDTO professorDTO){
        try{
            ConexaoDAO.ConectDB();
            stmt = ConexaoDAO.con.createStatement();
            String comando = "Delete from Professor where id_prof = " + professorDTO.getId_prof();
            
            stmt.execute(comando);
            ConexaoDAO.con.commit();
            stmt.close();
            return true;
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            return false;
        }
        finally{
            ConexaoDAO.CloseDB();
        }
    }
    
    public boolean alterarProfessor(ProfessorDTO professorDTO){
        try{
            ConexaoDAO.ConectDB();
            stmt = ConexaoDAO.con.createStatement();
            String comando = "Update Professor set "
                    + "nome_prof = '" + professorDTO.getNome_prof() + "', "
                    + "email_prof = '" + professorDTO.getEmail_prof() + "', "
                    + "senha_prof = '" + professorDTO.getSenha_prof() + "' "
                    + "where id_prof = " + professorDTO.getId_prof();
            
            stmt.execute(comando);
            ConexaoDAO.con.commit();
            stmt.close();
            return true;
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            return false;
        }
        finally{
            ConexaoDAO.CloseDB();
        }
        
    }
    
    public ResultSet consultarProfessor(ProfessorDTO professorDTO, int opcao){
        try{
            ConexaoDAO.ConectDB();
            stmt = ConexaoDAO.con.createStatement();
            String comando = "";
            switch (opcao){
                case 1:
                    comando = "Select p.* "+
                            "from Professor p "+
                            "where nome_prof like '" + professorDTO.getNome_prof() + "%' " +
                            "order by p.nome_prof";
                    break;
                case 2:
                    comando = "Select p.* "+
                            "from Professor p "+
                            "where email_prof like '" + professorDTO.getEmail_prof() + "%' " +
                            "order by p.email_prof";
                break;
                case 3:
                    comando = "Select p.* "+
                            "from Professor p "+
                            "where p.id_prof = " + professorDTO.getId_prof();
                break;
            }
            
            rs = stmt.executeQuery(comando);
            return rs;
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            return rs;
        }
    }
}
