
package br.com.chishiki.dao;

import br.com.chishiki.dto.AlunoDTO;
import java.sql.*;

public class AlunoDAO {
    public AlunoDAO(){   
    }
    
    private ResultSet rs = null;
    private Statement stmt = null;
    
    public boolean inserirAluno(AlunoDTO alunoDTO){
        try{
            ConexaoDAO.ConectDB();
            stmt = ConexaoDAO.con.createStatement();
            String comando = "Insert into Aluno (nome_alu, email_alu, senha_alu, curso_alu) values ( "
                    + "'" + alunoDTO.getNome_alu() + "', "
                    + "'" + alunoDTO.getEmail_alu() + "', "
                    + "'" + alunoDTO.getSenha_alu() + "', "
                    + "'" + alunoDTO.getCurso_alu() + "') ";
            
            stmt.execute(comando);
            ConexaoDAO.con.commit();
            stmt.close();
            return true;
        }
        
        catch (Exception e){
            System.out.println(e.getMessage());
            return false;
        }
        
        finally{
            ConexaoDAO.CloseDB();
        }
    }
    
    public boolean excluirAluno(AlunoDTO alunoDTO){
        try{
            ConexaoDAO.ConectDB();
            stmt = ConexaoDAO.con.createStatement();
            String comando = "Delete from Aluno where id_alu = " + alunoDTO.getId_alu();
            
            stmt.execute(comando);
            ConexaoDAO.con.commit();
            stmt.close();
            return true;
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            return false;
        }
        finally{
            ConexaoDAO.CloseDB();
        }
    }
    
    public boolean alterarAluno(AlunoDTO alunoDTO){
        try{
            ConexaoDAO.ConectDB();
            stmt = ConexaoDAO.con.createStatement();
            String comando = "Update Aluno set "
                    + "nome_alu = '" + alunoDTO.getNome_alu() + "', "
                    + "email_alu = '" + alunoDTO.getEmail_alu() + "', "
                    + "senha_alu = '" + alunoDTO.getSenha_alu() + "', "
                    + "curso_alu = '" + alunoDTO.getCurso_alu() + "', "
                    + "where id_alu = " + alunoDTO.getId_alu();

            stmt.execute(comando);
            ConexaoDAO.con.commit();
            stmt.close();
            return false;
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            return false;
        }
        finally{
            ConexaoDAO.CloseDB();
        }
        
    }
    
    public ResultSet consultarAluno(AlunoDTO alunoDTO, int opcao){
        try{
            ConexaoDAO.ConectDB();
            stmt = ConexaoDAO.con.createStatement();
            String comando = "";
            switch (opcao){
                case 1:
                    comando = "Select a.* "+
                            "from Aluno a "+
                            "where nome_alu like '" + alunoDTO.getNome_alu() + "%' " +
                            "order by a.nome_alu";
                break;
                
                case 2:
                    comando = "Select a.* "+
                            "from Aluno a "+
                            "where email_alu like '" + alunoDTO.getEmail_alu() + "%' " +
                            "order by a.email_alu";
                break;
                
                case 3:
                    comando = "Select a.* "+
                            "from Aluno a "+
                            "where curso_alu like '" + alunoDTO.getCurso_alu() + "%' " +
                            "order by a.curso_alu";
                break;
                
                case 4:
                    comando = "Select a.* "+
                            "from Aluno a "+
                            "where a.id_alu = " + alunoDTO.getId_alu();
                break;
            }
            rs = stmt.executeQuery(comando);
            return rs;
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            return rs;
        }
    } 
}
