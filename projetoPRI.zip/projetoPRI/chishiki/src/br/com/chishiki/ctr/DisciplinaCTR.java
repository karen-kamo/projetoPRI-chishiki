
package br.com.chishiki.ctr;

import java.sql.ResultSet;
import br.com.chishiki.dto.DisciplinaDTO;
import br.com.chishiki.dao.DisciplinaDAO;
import br.com.chishiki.dao.ConexaoDAO;

public class DisciplinaCTR {
    DisciplinaDAO disciplinaDAO = new DisciplinaDAO();
    
    public DisciplinaCTR(){
        
    }
    
    public String inserirDisciplina(DisciplinaDTO disciplinaDTO){
        try{
            if(disciplinaDAO.inserirDisciplina(disciplinaDTO)){
                return "Disciplina cadastrada com sucesso!";
            } else{
                return "Disciplina não cadastrada!";
            }
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            return "Disciplina não cadastrada!";
        }
    }
    
    public String alterarDisciplina(DisciplinaDTO disciplinaDTO){
        try{
            if(disciplinaDAO.alterarDisciplina(disciplinaDTO)){
                return "Disciplina alterada com sucesso!";
            }else{
                return "Disciplina não alterada!";
            }
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            return "Disciplina não alterada!";
        }
    }
    
    public String excluirDisciplina(DisciplinaDTO disciplinaDTO){
        try{
            if(disciplinaDAO.excluirDisciplina(disciplinaDTO)){
                return "Disciplina excluída com sucesso!";
            } else{
                return "Discipina não excluída!";
            }
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            return "Disciplina não excluída!";
        }
    }
    
    public ResultSet consultarDisciplina(DisciplinaDTO disciplinaDTO, int opcao){
        ResultSet rs = null;
        rs = disciplinaDAO.consultarDisciplina(disciplinaDTO, opcao);
        return rs;
    }
    
    public void CloseDB(){
        ConexaoDAO.CloseDB();
    }
}
