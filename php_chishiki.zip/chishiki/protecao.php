<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Chishiki </title>
    <link href="dist/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            margin: 0;
            padding: 0;
            background-color: #a37cf2;
        }

        .titulo {
            font-size: 4em;
            font-weight: bold;
            color: white;
            text-align: center;
            margin-top: 1em;
        }

        .titulo-palavra {
            border: 10px white solid;
            padding: 0.3em;
        }

        .paragrafo {
            font-size: 1.8em;
            margin-top: 2em;
            color: white;
        }

        .retangulo1 {
            background-color: #6919a6;
            margin: 3.5em 0 2em 0;
            border-radius: 10px;
            height: 6.5em;
        }

        .retangulo2 {
            background-color: #6919a6;
            margin: 3.5em 0 2em 0;
            border-radius: 10px;
            height: 6.5em;
        }

        .restrito {
            border: 10px double #8e40c9;
            border-radius: 10px;
            background-color: white;
            font-size: 1.7em;
            margin: 2.3em 15em 3em 15em;
            padding: 2.7em;
        }

        .btn_voltar {
            width: 10em;
            background-color: #693eb5;
            color: white;
        }

        .btn_voltar:hover {
            color: white;
            background-color: #5626ab;
        }

        .titulo2 {
            background: #7917CF;
            background: linear-gradient(to right, #7917CF 0%, #CF1512 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            font-weight: bold;
        }
    </style>
</head>

<body>
    <header>
        <div class="row">
            <div class="col text-center retangulo1">

            </div>

            <p class=" col titulo text-center">
                <span class="titulo-palavra"> CHISHIKI </span>
            </p>

            <div class="col text-center retangulo2">

            </div>
        </div>



        <div class="row">
            <div class="col text-center restrito">
                <h3 class="titulo2"> - CONTEÚDO RESTRITO - </h3>
                <p>Você está acessando um conteúdo restrito </p>
                <a class="btn btn-lg m-4 btn_voltar" href="escolhanivel.php" role="button">
                    <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-house-door" viewBox="0 0 16 16">
                        <path d="M8.354 1.146a.5.5 0 0 0-.708 0l-6 6A.5.5 0 0 0 1.5 7.5v7a.5.5 0 0 0 .5.5h4.5a.5.5 0 0 0 .5-.5v-4h2v4a.5.5 0 0 0 .5.5H14a.5.5 0 0 0 .5-.5v-7a.5.5 0 0 0-.146-.354L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293L8.354 1.146ZM2.5 14V7.707l5.5-5.5 5.5 5.5V14H10v-4a.5.5 0 0 0-.5-.5h-3a.5.5 0 0 0-.5.5v4H2.5Z" />
                    </svg>
                    Faça login
                </a>
            </div>

        </div>
        <div class="row">

        </div>

    </header>

</body>

</html>