<?php
require "conexao.php";

$id_alu = $_SESSION["usuario_id"];



if (isset($_GET["search"]) && !empty($_GET["search"])) {

    // TROCAR POR FIOLTER
    $search = filter_input(INPUT_GET, "search", FILTER_SANITIZE_SPECIAL_CHARS);


    $sql = "select p.id_perg, p.conteudo_perg, p.id_alu, p.id_disc, a.nome_alu, d.nome_disc
    FROM pergunta p
    join aluno a on a.id_alu = p.id_alu
    join disciplina d on d.id_disc = p.id_disc
    where lower(conteudo_perg) like '%$search%'
    order by id_perg";

?>
    <p class="text-pesq">
        <svg xmlns="http://www.w3.org/2000/svg" width="23" height="23" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">
            <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z" />
        </svg>
        <b>Resultados da busca por:</b> <?= $search ?>
    </p>
<?php
} else {
    $sql = "select p.id_perg, p.conteudo_perg, p.id_alu, p.id_disc, a.nome_alu, d.nome_disc
FROM pergunta p
join aluno a on a.id_alu = p.id_alu
join disciplina d on d.id_disc = p.id_disc
order by id_perg";
}




$stmt = $conn->query($sql);
while ($row = $stmt->fetch()) {
?>

    <div class="caixinha">
        <div class="row">
            <div class="col">

                Dúvida de: <b> <?= $row['nome_alu'] ?></b>
            </div>

            <div class="col text-center">

                Disciplina: <b><?= $row['nome_disc'] ?></b>
            </div>
        </div>

        <hr>
        <p class="caixinha-pergText">
            <?= $row['conteudo_perg'] ?>
        </p>
        <hr>

        <?php

        if ($id_alu == $row['id_alu']) {
        ?>
            <div class="row ">


                <div class="col text-center">
                    <form action="formperg-alterar.php" method="POST">
                        <input type="hidden" name="id_perg" value="<?= $row['id_perg'] ?>" required>
                        <button class="btn btn-warning" type="submit">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
                                <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z" />
                                <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z" />
                            </svg>
                            Alterar
                        </button>
                    </form>
                </div>
                <div class="col text-center">
                    <a class="btn btn-danger" href="excluir-perg.php?id_perg=<?= $row['id_perg'] ?>" role="button" onclick="if(!confirm('Tem certeza que deseja excluir?')) return false;">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
                            <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z" />
                            <path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z" />
                        </svg>
                        Excluir
                    </a>
                </div>
                <div class="col text-center">
                    <form action="ver-resp.php" method="POST">
                        <input type="hidden" name="id_perg" value="<?= $row['id_perg'] ?>" required>
                        <button class="btn btn-dark" type="submit">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-list-ul" viewBox="0 0 16 16">
                                <path fill-rule="evenodd" d="M5 11.5a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zm-3 1a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm0 4a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm0 4a1 1 0 1 0 0-2 1 1 0 0 0 0 2z" />
                            </svg>
                            Ver respostas
                        </button>
                    </form>

                </div>
            </div>
            <?php
        } else {
            if (autenticado()) {
            ?>
                <div class="row">

                    <div class="col text-center">
                        <form action="ver-resp.php" method="POST">
                            <input type="hidden" name="id_perg" value="<?= $row['id_perg'] ?>" required>
                            <button class="btn btn-dark" type="submit">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-list-ul" viewBox="0 0 16 16">
                                    <path fill-rule="evenodd" d="M5 11.5a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zm-3 1a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm0 4a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm0 4a1 1 0 1 0 0-2 1 1 0 0 0 0 2z" />
                                </svg>
                                Ver respostas
                            </button>
                        </form>
                    </div>
                    <div class="col text-center">
                        <form action="formresp.php" method="POST">
                            <input type="hidden" name="id_disc" value="<?= $row['id_disc'] ?>" required>
                            <input type="hidden" name="id_perg" value="<?= $row['id_perg'] ?>" required>
                            <button class="btn btn-dark" type="submit">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-pencil" viewBox="0 0 16 16">
                                    <path d="M12.146.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1 0 .708l-10 10a.5.5 0 0 1-.168.11l-5 2a.5.5 0 0 1-.65-.65l2-5a.5.5 0 0 1 .11-.168l10-10zM11.207 2.5 13.5 4.793 14.793 3.5 12.5 1.207 11.207 2.5zm1.586 3L10.5 3.207 4 9.707V10h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.293l6.5-6.5zm-9.761 5.175-.106.106-1.528 3.821 3.821-1.528.106-.106A.5.5 0 0 1 5 12.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.468-.325z" />
                                </svg>
                                Responder
                            </button>
                        </form>
                    </div>
                </div>
            <?php
            } else {
            ?>
                <div class="row">

                    <div class="col btn_direita">
                        <form action="ver-resp.php" method="POST">
                            <input type="hidden" name="id_perg" value="<?= $row['id_perg'] ?>" required>
                            <button class="btn btn-dark" type="submit">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-list-ul" viewBox="0 0 16 16">
                                    <path fill-rule="evenodd" d="M5 11.5a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zm-3 1a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm0 4a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm0 4a1 1 0 1 0 0-2 1 1 0 0 0 0 2z" />
                                </svg>
                                Ver respostas
                            </button>
                        </form>
                    </div>
                </div>
        <?php
            }
        }
        ?>
    </div>
<?php
}
?>

<div class="row">
    <div class="col text-center">
        <a class="btn btn-lg m-4 btn_voltar" href="#" role="button">
            <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-house-door" viewBox="0 0 16 16">
                <path d="M8.354 1.146a.5.5 0 0 0-.708 0l-6 6A.5.5 0 0 0 1.5 7.5v7a.5.5 0 0 0 .5.5h4.5a.5.5 0 0 0 .5-.5v-4h2v4a.5.5 0 0 0 .5.5H14a.5.5 0 0 0 .5-.5v-7a.5.5 0 0 0-.146-.354L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293L8.354 1.146ZM2.5 14V7.707l5.5-5.5 5.5 5.5V14H10v-4a.5.5 0 0 0-.5-.5h-3a.5.5 0 0 0-.5.5v4H2.5Z" />
            </svg>
            Voltar
        </a>
    </div>
</div>


<script>
    function conf_apagar() {
        confirm("Deseja realmente excluir?");
    }
</script>