<?php
session_start();
require("logica-autenticacao.php");

if (!autenticado()) {
    $_SESSION["restrito"] = true;
    redireciona(("protecao.php"));
    die();
}

require "conexao.php";


$conteudo_perg = filter_input(INPUT_POST, "conteudo_perg", FILTER_SANITIZE_SPECIAL_CHARS);
$id_alu = filter_input(INPUT_POST, "id_alu", FILTER_SANITIZE_NUMBER_INT);
$id_disc = filter_input(INPUT_POST, "id_disc", FILTER_SANITIZE_NUMBER_INT);
//$anonimato = filter_input(INPUT_POST, "anonimato", FILTER_SANITIZE_SPECIAL_CHARS);


//echo "$conteudo_perg";
//echo "$id_alu";

$sql = "insert into pergunta (conteudo_perg, id_alu, id_disc) values (?, ?, ?)";

try {
    $stmt = $conn->prepare($sql);
    $result = $stmt->execute([$conteudo_perg, $id_alu, $id_disc]);

} catch (Exception $e) {
    $result= false;
    $error = $e->getMessage();
}

if ($result == true) {
    $_SESSION["result"] = true;
    $_SESSION["msg"] = "Dados gravados corretamente.";
} else {
    $_SESSION["result"] = false;
    $_SESSION["erro"] = $error;
}

redireciona("formperg.php");

?>
