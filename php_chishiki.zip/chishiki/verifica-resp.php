<?php

session_start();
require("logica-autenticacao.php");

if (!autenticado()) {
    $_SESSION["restrito"] = true;
    redireciona(("protecao.php"));
    die();
}

require "conexao.php";

$id_resp = filter_input(INPUT_GET, "id_resp", FILTER_SANITIZE_NUMBER_INT);
$verdade = true;

$sql = "update resposta set
                    verifica = ?
                   where id_resp = ?";

try {
    $stmt = $conn->prepare($sql);
    $result = $stmt->execute([$verdade, $id_resp]);
} catch (Exception $e) {
    $result = false;
    $error = $e->getMessage();
}

// Pontuação
$sql = "select a.pont_alu, a.id_alu
FROM resposta r
join aluno a on a.id_alu = r.id_alu
where id_resp = ?";

try {
    $stmt = $conn->prepare($sql);
    $result = $stmt->execute([$id_resp]);
    $pontuacao = $stmt->fetch();
 
} catch (Exception $e) {
    $result = false;
    $error = $e->getMessage();
}

$novapont = $pontuacao["pont_alu"] + $_SESSION["pont-verif"];
$sql = "update aluno set
                    pont_alu = ?
                   where id_alu = ?";

try {
    $stmt = $conn->prepare($sql);
    $result = $stmt->execute([$novapont, $pontuacao["id_alu"]]);
} catch (Exception $e) {
    $result = false;
    $error = $e->getMessage();
}

redireciona("index.php");
