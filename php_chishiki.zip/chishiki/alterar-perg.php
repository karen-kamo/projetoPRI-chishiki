<?php
session_start();
require("logica-autenticacao.php");

if (!autenticado()) {
    $_SESSION["restrito"] = true;
    redireciona(("protecao.php"));
    die();
}

require "conexao.php";

$id_perg = filter_input(INPUT_POST, "id_perg", FILTER_SANITIZE_NUMBER_INT);
$conteudo_perg = filter_input(INPUT_POST, "conteudo_perg", FILTER_SANITIZE_SPECIAL_CHARS);
$id_alu = filter_input(INPUT_POST, "id_alu", FILTER_SANITIZE_NUMBER_INT);
$id_disc = filter_input(INPUT_POST, "id_disc", FILTER_SANITIZE_NUMBER_INT);

$sql = "update pergunta set
                    conteudo_perg = ?,
                    id_alu = ?,
                    id_disc = ?
                   where id_perg = ?";

try {
    $stmt = $conn->prepare($sql);
    $result = $stmt->execute([$conteudo_perg, $id_alu, $id_disc, $id_perg]);
} catch (Exception $e) {
    $result = false;
    $error = $e->getMessage();
}

if ($result == true) {
    $_SESSION["result"] = true;
    $_SESSION["msg"] = "Dados gravados corretamente.";
} else {
    $_SESSION["result"] = false;
    $_SESSION["erro"] = $error;
}

redireciona("index.php")
?>