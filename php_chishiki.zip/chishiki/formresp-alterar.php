<?php
session_start();
require("logica-autenticacao.php");
if (!autenticado()) {
    $_SESSION["restrito"] = true;
    redireciona(("protecao.php"));
    die();
}
require "header.php";

require "conexao.php";

$id = $_SESSION["usuario_id"];
$id_nada = null;
$id_perg = intval(filter_input(INPUT_POST, "id_perg", FILTER_SANITIZE_NUMBER_INT));
$id_resp = intval(filter_input(INPUT_POST, "id_resp", FILTER_SANITIZE_NUMBER_INT));

if (empty($id_resp)) {
    ?>
        <div class="alert alert-danger" role="alert">
            <h4>Falha ao abrir formulário para edição.</h4>
            <p>ID de resposta está vazio</p>
        </div>
    <?php
        exit;
}

$sql = "select p.id_perg, p.conteudo_perg, p.id_alu, p.id_disc, a.nome_alu, d.nome_disc
FROM pergunta p
join aluno a on a.id_alu = p.id_alu
join disciplina d on d.id_disc = p.id_disc
where id_perg = ?";
$stmt = $conn->prepare($sql);
$stmt->execute([$id_perg]);
$pergunta = $stmt->fetch();
?>

<main>
    <div class="d-flex">
        <div>
            <div class="caixinha">
                <div class="row">
                    <div class="col">

                        Dúvida de: <b><?= $pergunta['nome_alu'] ?></b>
                    </div>

                    <div class="col text-center">

                        Disciplina: <b><?= $pergunta['nome_disc'] ?></b>
                    </div>
                </div>

                <hr>
                <p class="caixinha-pergText">
                    <?= $pergunta['conteudo_perg'] ?>
                </p>
            </div>

            <?php
            $sql = "select conteudo_resp, id_alu, id_prof, id_perg FROM resposta where id_resp = ?";
            $stmt = $conn->prepare($sql);
            $stmt->execute([$id_resp]);
            $resposta = $stmt->fetch();
            ?>

            <form action="alterar-resp.php" method="POST">
                <div class="mb-3 form-respnv">
                    <h3 class="text-center titulo-formresp"> Altere sua resposta </h3> <br>
                    
                    <input type="hidden" name="id_resp" value="<?= $id_resp ?>" required>

                    <textarea class="mb-4 perg-resp" placeholder="Digite sua resposta aqui" id="conteudo_resp" name="conteudo_resp" style="height: 200px; width: 1000px" required autofocus><?= $resposta["conteudo_resp"] ?></textarea>

                    <?php
                    if (isProf()) {
                    ?>
                        <input type="hidden" name="id_alu" value="<?= $id_nada ?>" required>
                        <input type="hidden" name="id_prof" value="<?= $resposta["id_prof"] ?>" required>
                    <?php
                    } else {
                    ?>
                        <input type="hidden" name="id_alu" value="<?= $resposta["id_alu"] ?>" required>
                        <input type="hidden" name="id_prof" value="<?= $id_nada ?>" required>
                    <?php
                    }
                    ?>

                    <input type="hidden" name="id_perg" value="<?= $resposta['id_perg'] ?>" required>

                    <div class="row mt-4">
                        <div class="col text-center">
                            <button class="btn btn-lg btn-success" type="submit">
                                <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-check-lg" viewBox="0 0 16 16">
                                    <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                </svg>
                                Salvar
                            </button>
                        </div>

                        <div class="col text-center">
                            <button type="reset" class="btn btn-warning btn-lg">
                                <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-eraser-fill" viewBox="0 0 16 16">
                                    <path d="M8.086 2.207a2 2 0 0 1 2.828 0l3.879 3.879a2 2 0 0 1 0 2.828l-5.5 5.5A2 2 0 0 1 7.879 15H5.12a2 2 0 0 1-1.414-.586l-2.5-2.5a2 2 0 0 1 0-2.828l6.879-6.879zm.66 11.34L3.453 8.254 1.914 9.793a1 1 0 0 0 0 1.414l2.5 2.5a1 1 0 0 0 .707.293H7.88a1 1 0 0 0 .707-.293l.16-.16z" />
                                </svg>
                                Apagar
                            </button>
                        </div>
                        <div class="col text-center">
                            <a class="btn btn-danger btn-lg" href="index.php" role="button">
                                <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
                                    <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                                    <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z" />
                                </svg>
                                Cancelar
                            </a>
                        </div>
                    </div>
                </div>
            </form>


            <br>

            <?php
            if (isset($_SESSION["result"])) {
                if ($_SESSION["result"]) {
                    //inseriu certo
                    redireciona("ver-resp.php");
            ?>
                    <div class="alert alert-success alertas" role="alert">
                        <h4 class="alert-heading"> Sucesso! </h4>
                        <p>Dados alterados corretamente.</p>
                    </div>
                <?php

                } else {
                    //não inseriu deu erro
                    $erro = $_SESSION["erro"];
                    unset($_SESSION["erro"]);
                ?>
                    <div class="alert alert-danger alertas" role="alert">
                        <h4 class="alert-heading"> Falha ao efetuar gravação.</h4>
                        <p> Erro: <?= $erro ?> </p>
                    </div>

            <?php

                }
                unset($_SESSION["result"]);
            }
            ?>
        </div>
        <div class="flex-fill">
            <?php
            require "ranking.php";
            ?>
        </div>

    </div>
</main>


<?php
require "footer.php";
?>