<?php
session_start();
require("logica-autenticacao.php");

require "header.php";
require "conexao.php";


$id = $_SESSION["usuario_id"];
$nome = $_SESSION["usuario_nome"];

$id_perg = intval(filter_input(INPUT_POST, "id_perg", FILTER_SANITIZE_NUMBER_INT));

$sql = "select p.id_perg, p.conteudo_perg, p.id_alu, p.id_disc, a.nome_alu, d.nome_disc
FROM pergunta p
join aluno a on a.id_alu = p.id_alu
join disciplina d on d.id_disc = p.id_disc
where id_perg = ?";

$stmt = $conn->prepare($sql);
$result = $stmt->execute([$id_perg]);
$pergunta = $stmt->fetch();

$sql = "select id_perg, id_prof, id_alu 
            FROM resposta where id_perg = ?";

$stmt = $conn->prepare($sql);
$result = $stmt->execute([$id_perg]);
$verifica = $stmt->fetch();
?>

<main>
    <div class="d-flex">
        <div>
            <div class="caixinha">
                <div class="row">
                    <div class="col">

                        Dúvida de: <b><?= $pergunta['nome_alu'] ?></b>

                    </div>

                    <div class="col text-center">

                        Disciplina: <b><?= $pergunta['nome_disc'] ?></b>
                    </div>
                </div>

                <hr>
                <p class="caixinha-pergText">
                    <?= $pergunta['conteudo_perg'] ?>
                </p>

                <?php

                if (autenticado() && $_SESSION["usuario_nome"] != $pergunta["nome_alu"]) {
                ?>
                    <hr>
                    <div class="btn_direita">
                        <form action="formresp.php" method="POST">
                            <input type="hidden" name="id_disc" value="<?= $pergunta['id_disc'] ?>" required>
                            <input type="hidden" name="id_perg" value="<?= $pergunta['id_perg'] ?>" required>
                            <button class="btn btn-dark" type="submit">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-pencil" viewBox="0 0 16 16">
                                    <path d="M12.146.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1 0 .708l-10 10a.5.5 0 0 1-.168.11l-5 2a.5.5 0 0 1-.65-.65l2-5a.5.5 0 0 1 .11-.168l10-10zM11.207 2.5 13.5 4.793 14.793 3.5 12.5 1.207 11.207 2.5zm1.586 3L10.5 3.207 4 9.707V10h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.293l6.5-6.5zm-9.761 5.175-.106.106-1.528 3.821 3.821-1.528.106-.106A.5.5 0 0 1 5 12.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.468-.325z" />
                                </svg>
                                Responder
                            </button>
                        </form>
                    </div>
                <?php
                }
                ?>
            </div>
            <h2 class="titulo_ver-resp"> RESPOSTAS DOS PROFESSORES </h2>

            <?php

            if ($id_perg == $verifica["id_perg"]) {

                $sql = "select r.id_resp, r.id_prof, r.conteudo_resp, professor.nome_prof
                    FROM resposta r
                    join pergunta p on p.id_perg = r.id_perg
                    join professor on professor.id_prof = r.id_prof
                    where r.id_perg = ?";

                $stmt = $conn->prepare($sql);
                $result = $stmt->execute([$verifica["id_perg"]]);

                while ($resposta = $stmt->fetch()) {

            ?>
                    <div class="caixinha">
                        <div class="row">
                            <div class="col">

                                Respondido por: <b><?= $resposta['nome_prof'] ?></b>
                            </div>
                        </div>
                        <hr>
                        <p>
                            <?= $resposta['conteudo_resp'] ?>

                        </p>
                        <?php

                        if ($id == $resposta["id_prof"] && $nome == $resposta["nome_prof"]) {

                        ?>
                            <hr>
                            <div class="row">


                                <div class="col text-center">


                                    <form action="formresp-alterar.php" method="POST">
                                        <input type="hidden" name="id_resp" value="<?= $resposta["id_resp"] ?>" required>
                                        <input type="hidden" name="id_perg" value="<?= $pergunta["id_perg"] ?>" required>
                                        <button class="btn btn-warning" type="submit">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
                                                <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z" />
                                                <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z" />
                                            </svg>
                                            Alterar
                                        </button>
                                    </form>
                                </div>
                                <div class="col text-center">
                                    <a class="btn btn-danger" href="excluir-resp.php?id_resp=<?= $resposta["id_resp"] ?>" role="button" onclick="if(!confirm('Tem certeza que deseja excluir?')) return false;">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
                                            <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z" />
                                            <path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z" />
                                        </svg>
                                        Excluir
                                    </a>
                                </div>


                            </div>
                        <?php
                        }
                        ?>

                    </div>
                <?php
                }
            } else {
                ?>
                <div class="caixa-sem">
                    <p>
                        Não possuem respostas para essa pergunta.
                    </p>
                    <?php
                    if (!autenticado()) {
                    ?>
                        <p> Realize o seu cadastro para responder!</p>
                        <?php
                    } else {
                        if (isProf()) {
                        ?>
                            <p>
                                Responda a esta pergunta pela primeira vez!
                            </p>
                    <?php
                        }
                    }
                    ?>
                </div>
            <?php
            }
            ?>

            <h2 class="titulo_ver-resp"> RESPOSTAS DOS ALUNOS </h2>
            <?php

            if ($id_perg == $verifica["id_perg"]) {

                $sql = "select r.id_resp, r.verifica, r.id_alu, r.conteudo_resp, a.nome_alu, p.id_perg
                        FROM resposta r
                        join pergunta p on p.id_perg = r.id_perg
                        join aluno a on a.id_alu = r.id_alu
                        where r.id_perg = ?";

                $stmt = $conn->prepare($sql);
                $result = $stmt->execute([$id_perg]);

                while ($resposta = $stmt->fetch()) {
            ?>
                    <div class="caixinha">
                        <div class="row">
                            <div class="col">

                                Respondido por: <b><?= $resposta['nome_alu'] ?></b>
                            </div>
                        </div>

                        <hr>
                        <?php
                        if ($resposta["verifica"] == true) {
                        ?>
                            <p class="verificado">
                                <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-check-circle" viewBox="0 0 16 16">
                                    <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                                    <path d="M10.97 4.97a.235.235 0 0 0-.02.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-1.071-1.05z" />
                                </svg>
                                Verificado
                            </p>
                        <?php
                        }
                        ?>
                        <p>
                            <?= $resposta['conteudo_resp'] ?>
                        </p>
                        <?php
                        if (isProf()) {
                            if ($resposta["verifica"] == true) {
                        ?>
                                <hr>
                                <div class="row">
                                    <div class="col btn_direita">
                                        <a class="btn btn-dark" href="desverifica-resp.php?id_resp=<?= $resposta["id_resp"] ?>" role="button">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-file-excel" viewBox="0 0 16 16">
                                                <path d="M5.18 4.616a.5.5 0 0 1 .704.064L8 7.219l2.116-2.54a.5.5 0 1 1 .768.641L8.651 8l2.233 2.68a.5.5 0 0 1-.768.64L8 8.781l-2.116 2.54a.5.5 0 0 1-.768-.641L7.349 8 5.116 5.32a.5.5 0 0 1 .064-.704z" />
                                                <path d="M4 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H4zm0 1h8a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1z" />
                                            </svg>
                                            Tirar verificado da resposta
                                        </a>

                                    </div>
                                </div>
                            <?php
                            } else {
                            ?>
                                <hr>
                                <div class="row">
                                    <div class="col btn_direita">
                                        <a class="btn btn-dark" href="verifica-resp.php?id_resp=<?= $resposta["id_resp"] ?>" role="button">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-check2-square" viewBox="0 0 16 16">
                                                <path d="M3 14.5A1.5 1.5 0 0 1 1.5 13V3A1.5 1.5 0 0 1 3 1.5h8a.5.5 0 0 1 0 1H3a.5.5 0 0 0-.5.5v10a.5.5 0 0 0 .5.5h10a.5.5 0 0 0 .5-.5V8a.5.5 0 0 1 1 0v5a1.5 1.5 0 0 1-1.5 1.5H3z" />
                                                <path d="m8.354 10.354 7-7a.5.5 0 0 0-.708-.708L8 9.293 5.354 6.646a.5.5 0 1 0-.708.708l3 3a.5.5 0 0 0 .708 0z" />
                                            </svg>
                                            Verificar resposta
                                        </a>

                                    </div>
                                </div>
                            <?php
                            }
                        }

                        if ($id == $resposta["id_alu"] && $nome == $resposta["nome_alu"]) {
                            ?>
                            <hr>
                            <div class="row">

                                <?php
                                if ($resposta["verifica"] == false) {
                                ?>
                                    <div class="col text-center">
                                        <form action="formresp-alterar.php" method="POST">
                                            <input type="hidden" name="id_resp" value="<?= $resposta["id_resp"] ?>" required>
                                            <input type="hidden" name="id_perg" value="<?= $pergunta["id_perg"] ?>" required>
                                            <button class="btn btn-warning" type="submit">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
                                                    <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z" />
                                                    <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z" />
                                                </svg>
                                                Alterar
                                            </button>
                                        </form>
                                    </div>
                                    <div class="col text-center">
                                        <a class="btn btn-danger" href="excluir-resp.php?id_resp=<?= $resposta["id_resp"] ?>" role="button" onclick="if(!confirm('Tem certeza que deseja excluir?')) return false;">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
                                                <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z" />
                                                <path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z" />
                                            </svg>
                                            Excluir
                                        </a>
                                    </div>
                                <?php
                                }
                                ?>
                            </div>
                        <?php
                        }
                        ?>
                    </div>
                <?php
                }
            } else {
                ?>
                <div class="caixa-sem">
                    <p>
                        Não possuem respostas para essa pergunta.
                    </p>
                    <?php
                    if (!autenticado()) {
                    ?>
                        <p> Realize o seu cadastro para responder!</p>
                        <?php
                    } else {
                        if (!isProf()) {
                        ?>
                            <p>
                                Responda a esta pergunta pela primeira vez!
                            </p>
                    <?php
                        }
                    }
                    ?>
                </div>
            <?php
            }
            ?>
            <div class="row">
                <div class="col text-center">
                    <a class="btn btn-lg m-4 btn_voltar" href="#" role="button">
                        <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-house-door" viewBox="0 0 16 16">
                            <path d="M8.354 1.146a.5.5 0 0 0-.708 0l-6 6A.5.5 0 0 0 1.5 7.5v7a.5.5 0 0 0 .5.5h4.5a.5.5 0 0 0 .5-.5v-4h2v4a.5.5 0 0 0 .5.5H14a.5.5 0 0 0 .5-.5v-7a.5.5 0 0 0-.146-.354L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293L8.354 1.146ZM2.5 14V7.707l5.5-5.5 5.5 5.5V14H10v-4a.5.5 0 0 0-.5-.5h-3a.5.5 0 0 0-.5.5v4H2.5Z" />
                        </svg>
                        Voltar
                    </a>
                </div>
            </div>
        </div>
        <div class="flex-fill">
            <?php
            require "ranking.php";
            ?>
        </div>
    </div>


</main>

<?php
require "footer.php";
?>