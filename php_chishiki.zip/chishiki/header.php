<?php

require "conexao.php";
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chishiki</title>
    <link href="dist/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            background-color: #fffefc;
        }

        /* Header */
        header {
            background-color: purple;
            font-size: 2.5em;
            padding: 0.7em;
        }

        .link-chishiki {
            color: white;
            text-decoration: none;

        }

        .link-chishiki:hover {
            color: white;
        }

        .pesquisa {
            margin-top: 0.3em;
        }

        .perfil {
            color: white;
        }

        .perfil:hover {
            color: white;
        }

        .disciplinas {
            background-color: #ea8cff;
            padding: 1em;
        }

        #btn-secondary {
            color: #fff;
            background-color: #4b1369;
            border-color: #4b1369;
        }

        /* Index */

        .btn_cadPerg {
            background-color: #4b1369;
            border: #4b1369;
            height: 2.8em;
            width: 13em;
            text-align: center;
            font-size: 0.4em;
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .btn_cadPerg:hover {
            background-color: #6f14a3;
            border: #6f14a3;
        }

        .btn_cadPerg-texto {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .btn_cadPerg-texto:hover {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        /* Ranking */
        .titulo-ranking {
            color: white;
            background-color: #000000;
            font-weight: bold;
            padding: 0.3em;
            background: rgb(1, 38, 87);
            background: linear-gradient(158deg, rgba(1, 38, 87, 1) 17%, rgba(91, 34, 158, 1) 90%);
        }

        .flex-fill {
            border-left: 3px solid #091952;
        }

        .ranking {
            text-align: center;
        }

        .ranking3 {
            padding-bottom: 0.5em;

        }

        .rest-ranking {
            padding: 1em 0 0 1.5em;
            border-top: 3px solid #091952;
            text-align: left;
        }

        #icon1 {
            color: gold
        }

        #icon2 {
            color: silver;
        }

        #icon3 {
            color: brown;
        }

        /*Nova pergunta */
        .titulo-formperg {
            background: #720C82;
            background: linear-gradient(to right, #720C82 0%, #CF1512 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            font-weight: bold;
            text-decoration: overline #961e58 5px;
        }

        .form-pergnv {
            margin: 2em 2em 5em 2em;
            -webkit-box-shadow: 1px 1px 15px -4px #000000;
            box-shadow: 1px 1px 15px -4px #000000;
            padding: 2em;
            border-radius: 10px;
            background-color: #fce8fc;
        }

        .alertas {
            width: 50em;
            margin-left: 11em;

        }

        /* Nova resposta */

        .titulo-formresp {
            background: #720C82;
            background: linear-gradient(to right, #720C82 0%, #CF1512 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            font-weight: bold;
            text-decoration: overline #961e58 5px;
        }

        .form-respnv {
            margin: 3.5em 2em 5em 2em;
            -webkit-box-shadow: 1px 1px 15px -4px #000000;
            box-shadow: 1px 1px 15px -4px #000000;
            padding: 2em;
            border-radius: 10px;
            background-color: #fce8fc;
        }

        /* Footer */
        footer {
            background-color: #91917c;
            padding: 2.5em 2.5em 0.5em 2.5em;
        }

        .texto-footer {
            text-indent: 1.5em;
            text-align: justify;
            color: #3c3d42;
        }

        .titulo-footer {
            font-weight: bold;
        }

        .texto2-footer {
            border-left: 2px dashed #3c3d42;
        }

        .texto-desenvolvedores {
            border-top: 2px dashed #3c3d42;
            padding: 1em;
            margin-top: 1em;
            color: #3c3d42;
            font-size: 1.2em;
        }

        /* Index */
        .verificado {
            text-align: left;
            color: green;
            -webkit-box-shadow: 1px 1px 19px -8px #000000;
            box-shadow: 1px 1px 19px -8px #000000;
            border-radius: 40px;
            padding: 0.5em;
            width: 8em;
            margin-bottom: 0.8em;
            background-color: #dafad9;
        }

        /* Ver respostas */
        .titulo_ver-resp {
            margin: 2em 2em 1em 2em;
            text-align: center;
            background: #35169C;
            background: #121FCF;
            background: linear-gradient(to right, #121FCF 0%, #CF1512 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            font-weight: bold;
            text-decoration: overline 5px purple;
        }


        /* Perguntas */
        .caixinha {
            margin: 2em 3em 2em 3em;
            text-align: justify;
            padding: 1.5em;
            width: 65em;
            min-height: 10em;
            max-height: 100em;
            border-radius: 10px;
            -webkit-box-shadow: 3px 3px 15px -3px #000000;
            box-shadow: 3px 3px 15px -3px #000000;
        }

        .btn_voltar {
            width: 10em;
            background-color: #693eb5;
            color: white;
        }

        .btn_voltar:hover {
            color: white;
            background-color: #5626ab;
        }

        /* Geral */
        .caixa-sem {
            -webkit-box-shadow: 0px 0px 22px -8px #000000;
            box-shadow: 0px 0px 22px -8px #000000;
            width: 54em;
            margin: 2em 2.5em 2em 2.5em;
            padding: 1.5em;
            border-radius: 10px;
            text-align: center;
            font-size: 1.2em;
        }

        .btn_direita {
            text-align: right;
        }

        .btn-todos {
            color: #fff;
            background-color: #4b1369;
            border-color: #4b1369;
        }

        .perg-resp {
            border-radius: 5px;
            border: 1px solid #d8d7d9;
        }

        /*Perfil */
        .caixa-perfil {
            margin: 2em 2em 5em 2em;
            padding: 2em;
            width: 65em;
            -webkit-box-shadow: 1px 1px 15px -4px #000000;
            box-shadow: 1px 1px 15px -4px #000000;
            border-radius: 10px;
            background-color: #fce8fc;
        }

        .campos-perfil {
            margin: 1.5em;
            font-size: 1em;
        }

        .text-pesq {
            font-size: 1.7em;
            text-align: center;
            margin: 1em;
            border-bottom: 2px dashed black;
            border-top: 2px dashed black;
            padding: 0.5em;
            width: 39.7em;
        }

        .caixa-sem-perg {
            -webkit-box-shadow: 0px 0px 22px -8px #000000;
            box-shadow: 0px 0px 22px -8px #000000;
            width: 54em;
            margin: 6em 2.5em 2em 2.5em;
            padding: 1.5em;
            border-radius: 10px;
            text-align: center;
            font-size: 1.2em;
        }
    </style>
    <script>
        function alerta_deslogado() {
            alert("Você saiu do sistema! Volte sempre");
        }
    </script>
</head>

<body>
    <?php
    if (!function_exists("autenticado")) {
    ?>
        <br>
        <h1> Atenção você esqueceu o require do arquivo \"logica-autenticacao.php\"!; </h1>
    <?php
        die();
    }
    ?>
    <header>
        <div class="row text-center">
            <div class="col-3">
                <a href="index.php" class="link-chishiki">
                    <svg xmlns="http://www.w3.org/2000/svg" width="55" height="55" fill="currentColor" class="bi bi-mortarboard-fill" viewBox="0 0 16 16">
                        <path d="M8.211 2.047a.5.5 0 0 0-.422 0l-7.5 3.5a.5.5 0 0 0 .025.917l7.5 3a.5.5 0 0 0 .372 0L14 7.14V13a1 1 0 0 0-1 1v2h3v-2a1 1 0 0 0-1-1V6.739l.686-.275a.5.5 0 0 0 .025-.917l-7.5-3.5Z" />
                        <path d="M4.176 9.032a.5.5 0 0 0-.656.327l-.5 1.7a.5.5 0 0 0 .294.605l4.5 1.8a.5.5 0 0 0 .372 0l4.5-1.8a.5.5 0 0 0 .294-.605l-.5-1.7a.5.5 0 0 0-.656-.327L8 10.466 4.176 9.032Z" />
                    </svg>
                    CHISHIKI
                </a>
            </div>
            <div class="col-5">
                <div class="pesquisa">
                    <form class="d-flex" role="search" method="GET" action="index.php">
                        <input class="form-control me-2" type="search" name="search" placeholder="Pesquise por palavras-chaves para achar sua dúvida" aria-label="Search">
                        <button class="btn btn-primary" type="submit">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">
                                <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z" />
                            </svg>
                        </button>
                    </form>
                </div>
            </div>

            <?php
            if (isProf() || !autenticado()) {
            ?>
                <div class="col-2">
                    <button type="button" class="btn btn_cadPerg" disabled> NOVA PERGUNTA </button>
                </div>
            <?php
            } else {
            ?>
                <div class="col-2">
                    <button type="button" class="btn btn_cadPerg">
                        <a href="formperg.php" class="btn_cadPerg-texto">
                            NOVA PERGUNTA
                        </a>
                    </button>
                </div>
            <?php
            }
            ?>

            <div class="col-2">

                <?php
                if (autenticado()) {
                    if (isProf()) {
                ?>
                        <a href="perfil.php" class="perfil">
                            <svg xmlns="http://www.w3.org/2000/svg" width="45" height="45" fill="currentColor" class="bi bi-person-workspace" viewBox="0 0 16 16">
                                <path d="M4 16s-1 0-1-1 1-4 5-4 5 3 5 4-1 1-1 1H4Zm4-5.95a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Z" />
                                <path d="M2 1a2 2 0 0 0-2 2v9.5A1.5 1.5 0 0 0 1.5 14h.653a5.373 5.373 0 0 1 1.066-2H1V3a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v9h-2.219c.554.654.89 1.373 1.066 2h.653a1.5 1.5 0 0 0 1.5-1.5V3a2 2 0 0 0-2-2H2Z" />
                            </svg>
                        </a>
                    <?php
                    } else {
                    ?>
                        <a href="perfil.php" class="perfil">
                            <svg xmlns="http://www.w3.org/2000/svg" width="45" height="45" fill="currentColor" class="bi bi-file-person" viewBox="0 0 16 16">
                                <path d="M12 1a1 1 0 0 1 1 1v10.755S12 11 8 11s-5 1.755-5 1.755V2a1 1 0 0 1 1-1h8zM4 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H4z" />
                                <path d="M8 10a3 3 0 1 0 0-6 3 3 0 0 0 0 6z" />
                            </svg>
                        </a>
                    <?php
                    }
                } else {
                    ?>
                    <a href="perfil.php" class="perfil">
                        <svg xmlns="http://www.w3.org/2000/svg" width="45" height="45" fill="currentColor" class="bi bi-person-circle" viewBox="0 0 16 16">
                            <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0z" />
                            <path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8zm8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1z" />
                        </svg>
                    </a>
                <?php
                }
                ?>

                <?php
                if (autenticado()) {
                ?>
                    <a href="sair.php" class="btn btn-danger" onclick="alerta_deslogado()">
                        <span data-feather="log-out"></span>
                        Sair
                    </a>

                <?php
                } else {
                ?>
                    <a href="escolhanivel.php" class="btn btn-light">
                        <span data-feather="log-in"></span>
                        Entrar
                    </a>

                <?php
                }
                ?>
            </div>
        </div>
    </header>

    <div class="row text-center disciplinas">
        <div class="col">
            <a class="btn btn-todos" href="index.php" role="button"> Todos</a>
        </div>

        <div class="col">
            <div class="dropdown">
                <button id="btn-secondary" class="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                    Exatas
                </button>
                <ul class="dropdown-menu">
                    <?php
                    $sql = "select id_disc, nome_disc, area_disc FROM disciplina";
                    $stmt = $conn->query($sql);
                    while ($disciplina = $stmt->fetch()) {
                        if ($disciplina["area_disc"] == "EXATAS") {
                            echo "<li><a class='dropdown-item' href='ver-perg_disc.php?id_disc=" . $disciplina['id_disc'] . "'> " . $disciplina['nome_disc'] . "</a></li>";
                            
                        }
                    }
                    ?>
                </ul>
            </div>
        </div>

        <div class="col">
            <div class="dropdown">
                <button id="btn-secondary" class="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                    Natureza
                </button>

                <ul class="dropdown-menu">
                    <?php
                    $sql = "select id_disc, nome_disc, area_disc FROM disciplina";
                    $stmt = $conn->query($sql);
                    while ($disciplina = $stmt->fetch()) {
                        if ($disciplina["area_disc"] == "NATUREZA") {
                            echo "<li><a class='dropdown-item' href='ver-perg_disc.php?id_disc=" . $disciplina['id_disc'] . "'> " . $disciplina['nome_disc'] . "</a></li>";
                        }
                    }
                    ?>
                </ul>
            </div>
        </div>

        <div class="col">
            <div class="dropdown">
                <button id="btn-secondary" class="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                    Humanas
                </button>
                <ul class="dropdown-menu">
                    <?php
                    $sql = "select id_disc, nome_disc, area_disc FROM disciplina";
                    $stmt = $conn->query($sql);
                    while ($disciplina = $stmt->fetch()) {
                        if ($disciplina["area_disc"] == "HUMANAS") {
                            echo "<li><a class='dropdown-item' href='ver-perg_disc.php?id_disc=" . $disciplina['id_disc'] . "'> " . $disciplina['nome_disc'] . "</a></li>";
                        }
                    }
                    ?>
                </ul>
            </div>
        </div>

        <div class="col">
            <div class="dropdown">
                <button id="btn-secondary" class="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                    Linguagens
                </button>
                <ul class="dropdown-menu">
                    <?php
                    $sql = "select id_disc, nome_disc, area_disc FROM disciplina";
                    $stmt = $conn->query($sql);
                    while ($disciplina = $stmt->fetch()) {
                        if ($disciplina["area_disc"] == "LINGUAGENS") {
                            echo "<li><a class='dropdown-item' href='ver-perg_disc.php?id_disc=" . $disciplina['id_disc'] . "'> " . $disciplina['nome_disc'] . "</a></li>";
                        }
                    }
                    ?>
                </ul>
            </div>
        </div>

        <div class="col">
            <div class="dropdown">
                <button id="btn-secondary" class="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                    Informática
                </button>
                <ul class="dropdown-menu">
                    <?php
                    $sql = "select id_disc, nome_disc, area_disc FROM disciplina";
                    $stmt = $conn->query($sql);
                    while ($disciplina = $stmt->fetch()) {
                        if ($disciplina["area_disc"] == "INFORMÁTICA") {
                            echo "<li><a class='dropdown-item' href='ver-perg_disc.php?id_disc=" . $disciplina['id_disc'] . "'> " . $disciplina['nome_disc'] . "</a></li>";
                        }
                    }
                    ?>
                </ul>
            </div>
        </div>

        <div class="col">
            <div class="dropdown">
                <button id="btn-secondary" class="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                    Edificações
                </button>
                <ul class="dropdown-menu">
                    <?php
                    $sql = "select id_disc, nome_disc, area_disc FROM disciplina";
                    $stmt = $conn->query($sql);
                    while ($disciplina = $stmt->fetch()) {
                        if ($disciplina["area_disc"] == "EDIFICAÇÕES") {
                            echo "<li><a class='dropdown-item' href='ver-perg_disc.php?id_disc=" . $disciplina['id_disc'] . "'> " . $disciplina['nome_disc'] . "</a></li>";
                        }
                    }
                    ?>
                </ul>
            </div>
        </div>

        <div class="col">
            <div class="dropdown">
                <button id="btn-secondary" class="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                    Mecatrônica
                </button>
                <ul class="dropdown-menu">
                    <?php
                    $sql = "select id_disc, nome_disc, area_disc FROM disciplina";
                    $stmt = $conn->query($sql);
                    while ($disciplina = $stmt->fetch()) {
                        if ($disciplina["area_disc"] == "MECATRÔNICA") {
                            echo "<li><a class='dropdown-item' href='ver-perg_disc.php?id_disc=" . $disciplina['id_disc'] . "'> " . $disciplina['nome_disc'] . "</a></li>";
                        }
                    }
                    ?>
                </ul>
            </div>
        </div>
    </div>