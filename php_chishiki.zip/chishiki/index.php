<?php
session_start();
require("logica-autenticacao.php"); 
require "header.php";
?>

<div class="d-flex">
        <div>
                <?php
                require "areaperg.php";
                ?>
        </div>


        <div class="flex-fill">
                <?php
                require "ranking.php";
                ?>
        </div>
</div>

<?php
require "footer.php";
?>




       


      