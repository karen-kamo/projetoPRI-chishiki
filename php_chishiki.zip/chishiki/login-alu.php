<?php
session_start();

require("logica-autenticacao.php");

if (autenticado()) {
    redireciona("index.php");
    die();
}

require "conexao.php";

$email_alu = strtoupper(filter_input(INPUT_POST, "email_alu", FILTER_SANITIZE_EMAIL));
$senha_alu = filter_input(INPUT_POST, "senha_alu");

$sql = "select id_alu, nome_alu, senha_alu from aluno where email_alu = ?";

$stmt = $conn->prepare($sql);
$result = $stmt->execute([$email_alu]);

$row = $stmt->fetch();

if (!empty($row["senha_alu"])) {

    if ($senha_alu == $row["senha_alu"]) {
        //senha está OK
        $_SESSION["usuario_nome"] = $row["nome_alu"];
        $_SESSION["usuario_email"] = $email_alu;
        $_SESSION["usuario_id"] = $row["id_alu"];
        $_SESSION["usuario_tipo"] = "aluno";
        $_SESSION["usuario_result"] = true;
        redireciona("index.php");
    } else {
        //senha ERRADA
        $_SESSION["usuario_result"] = false;
        $_SESSION["erro"] = "Senha incorreta";
        redireciona("form_login-alu.php");
    }
} else {
    $_SESSION["usuario_result"] = false;
    $_SESSION["erro"] = "Nenhum aluno encontrado com este email. Faça seu cadastro!";
    redireciona("form_login-alu.php");
}
