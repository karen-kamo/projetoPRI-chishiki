<?php
session_start();
require("logica-autenticacao.php");

if (!autenticado()) {
    $_SESSION["restrito"] = true;
    redireciona(("protecao.php"));
    die();
}

require "conexao.php";

$id_perg = intval(filter_input(INPUT_GET, "id_perg", FILTER_SANITIZE_NUMBER_INT));


$sql = "delete from pergunta where id_perg = ?";

$stmt = $conn->prepare($sql);
$result = $stmt->execute([$id_perg]);

if ($result == true) {
    $_SESSION["result"] = true;
    $_SESSION["msg"] = "Registro excluído com sucesso!";

} else {
    $_SESSION["result"] = false;
    $_SESSION["erro"] = $error;
}
redireciona("index.php");

?>