<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Chishiki </title>
    <link href="dist/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            margin: 0;
            padding: 0;
            background-color: #a37cf2;
        }

        .waves {
            position: absolute;
            bottom: 0;
            right: 0;
            left: 0;
        }

        .titulo {
            font-size: 4em;
            font-weight: bold;
            color: white;
            text-align: center;
            margin-top: 1em;
        }

        .titulo-palavra {
            border: 10px white solid;
            padding: 0.3em;
        }

        .paragrafo {
            font-size: 1.8em;
            margin-top: 2em;
            color: white;
        }

        .retangulo1 {
            background-color: #6919a6;
            margin: 3.5em 0 2em 0;
            border-radius: 10px;
            height: 6.5em;
        }

        .retangulo2 {
            background-color: #6919a6;
            margin: 3.5em 0 2em 0;
            border-radius: 10px;
            height: 6.5em;
        }

        .btn-acesso {
            width: 9em;
            height: 9em;
        }

        .nome-acesso {
            font-size: 1.5em;
            margin-top: 1.5em;
            color: white;
            font-weight: bold;
        }

        .setas {
            color: #330f7a;
            font-weight: bold;
        }
    </style>
</head>

<body>
    <header>
        <div class="row">
            <div class="col text-center retangulo1">

            </div>

            <p class=" col titulo text-center">
                <span class="titulo-palavra"> CHISHIKI </span>
            </p>

            <div class="col text-center retangulo2">

            </div>
        </div>



        <div class="row">
            <div class="col text-center nome-acesso">
                ALUNO
            </div>
            <div class="col">

            </div>
            <div class="col text-center nome-acesso">
                PROFESSOR
            </div>
        </div>
        <div class="row">
            <div class="col text-center">
                <a href="form_login-alu.php" class="btn btn-light me-2">
                    <img class="btn-acesso" src="images/imgalu.png" alt="">
                </a>
            </div>
            <div class="col text-center paragrafo">
                <svg class="setas" xmlns="http://www.w3.org/2000/svg" width="60" height="60" fill="currentColor" class="bi bi-arrow-left-circle" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M1 8a7 7 0 1 0 14 0A7 7 0 0 0 1 8zm15 0A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-4.5-.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5H11.5z" />
                </svg>

                Escolha seu nível de acesso
                <svg class="setas" xmlns="http://www.w3.org/2000/svg" width="60" height="60" fill="currentColor" class="bi bi-arrow-right-circle" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M1 8a7 7 0 1 0 14 0A7 7 0 0 0 1 8zm15 0A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM4.5 7.5a.5.5 0 0 0 0 1h5.793l-2.147 2.146a.5.5 0 0 0 .708.708l3-3a.5.5 0 0 0 0-.708l-3-3a.5.5 0 1 0-.708.708L10.293 7.5H4.5z" />
                </svg>
            </div>

            <div class="col text-center">
                <a href="form_login-prof.php" class="btn btn-light me-2">
                    <img class="btn-acesso" src="images/imgprof2.png" alt="">
                </a>
            </div>
        </div>
        <svg class="waves" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
            <path class="wave-1" fill="#781eb0" fill-opacity="1" d="M0,160L48,165.3C96,171,192,181,288,160C384,139,480,85,576,85.3C672,85,768,139,864,154.7C960,171,1056,149,1152,138.7C1248,128,1344,128,1392,128L1440,128L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path>
            <path class="wave-2" fill="#4d0c75" fill-opacity="1" d="M0,128L48,117.3C96,107,192,85,288,96C384,107,480,149,576,192C672,235,768,277,864,256C960,235,1056,149,1152,101.3C1248,53,1344,43,1392,37.3L1440,32L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path>
            <path class="wave-3" fill="#70438c" fill-opacity="1" d="M0,288L48,288C96,288,192,288,288,250.7C384,213,480,139,576,138.7C672,139,768,213,864,245.3C960,277,1056,267,1152,272C1248,277,1344,299,1392,309.3L1440,320L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path>
        </svg>
    </header>

</body>

</html>