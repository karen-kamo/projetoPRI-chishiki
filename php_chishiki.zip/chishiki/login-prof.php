<?php
session_start();

require("logica-autenticacao.php");

if (autenticado()) {
    redireciona("index.php");
    die();
}
require "conexao.php";

$email_prof = strtoupper(filter_input(INPUT_POST, "email_prof", FILTER_SANITIZE_EMAIL));
$senha_prof = filter_input(INPUT_POST, "senha_prof");

$sql = "select id_prof, nome_prof, senha_prof from professor where email_prof = ?";

$stmt = $conn->prepare($sql);
$result = $stmt->execute([$email_prof]);

$row = $stmt->fetch();

if (!empty($row["senha_prof"])) {
    if ($senha_prof == $row["senha_prof"]) {
        //senha está OK
        $_SESSION["usuario_nome"] = $row["nome_prof"];
        $_SESSION["usuario_email"] = $email_prof;
        $_SESSION["usuario_id"] = $row["id_prof"];
        $_SESSION["usuario_tipo"] = "prof";
        $_SESSION["usuario_result"] = true;
        redireciona("index.php");
    } else {
        //senha ERRADA
        $_SESSION["usuario_result"] = false;
        $_SESSION["erro"] = "Senha incorreta";
        redireciona("form_login-prof.php");
    }
} else {
    $_SESSION["usuario_result"] = false;
    $_SESSION["erro"] = "Nenhum professor encontrado com este email.";
    redireciona("form_login-prof.php");
}
