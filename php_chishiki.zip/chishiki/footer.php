

<footer>
    <div class="row texto-footer">
        <div class="col">
            <h5 class="titulo-footer">Sobre o projeto</h5>
            <p> Chishiki é um projeto que faz parte da disciplina Projeto Integrador (PRI). Por meio dele realizamos a construção de dois sistemas, um na linguagem Java e outro na linguagem PHP. O projeto consiste em um fórum online voltado para os alunos da nossa instituição, IFSP - campus Votuporanga. </p>
        </div>
        <div class="col texto2-footer">
            <h5 class="titulo-footer"> Agradecimentos </h5>
            <p>Gostaríamos de agradecer, primeiramente, ao nosso tutor Marcelo Murari por toda orientação em nosso projeto, e também, aos outros professores envolvidos como Cris, Eder, Bira, Gobbi, Cecílio e Natal. Agradecemos muito aos outros alunos também!</p>
        </div>
    </div>

    <div class="row text-center texto-desenvolvedores">
        <p> Copyright © 2022 Todos os Direitos Reservados. Desenvolvido por Karen Nanamy Kamo e Yasmin Vitória Siqueira de Lima. </p>
    </div>
</footer>
<script src="dist/bootstrap.bundle.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/feather-icons@4.28.0/dist/feather.min.js" integrity="sha384-uO3SXW5IuS1ZpFPKugNNWqTZRRglnUJK6UAZ/gxOX80nxEkN9NcGZTftn6RzhGWE" crossorigin="anonymous"></script>

<script src="dist/dashboard.js"></script>


</body>

</html>