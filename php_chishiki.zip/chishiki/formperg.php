<?php
session_start();
require("logica-autenticacao.php");
if (!autenticado()) {
    $_SESSION["restrito"] = true;
    redireciona(("protecao.php"));
    die();
}

require "header.php";


require "conexao.php";


$id = $_SESSION["usuario_id"];

?>

<main>

    <div class="d-flex">
        <div>
            <form action="inserir-perg.php" method="POST">
                <div class="mb-3 form-pergnv">
                    <h3 class="text-center titulo-formperg"> Faça uma nova pergunta </h3> <br>

                    <textarea class="mb-4 perg-resp" placeholder="Digite sua dúvida aqui" id="conteudo_perg" name="conteudo_perg" style="height: 200px; width: 1000px" required autofocus></textarea>
                   

                    <input type="hidden" name="id_alu" value="<?= $id ?>" required>

                    <select class="form-select mb-5" aria-label="Default select example" name="id_disc" id="id_disc" required>
                        <option value="" selected>Selecione a disciplina</option>
                        <?php

                        $sql = "select id_disc, nome_disc FROM disciplina";
                        $stmt = $conn->query($sql);

                        while ($row = $stmt->fetch()) {
                            echo "<option value=" . $row['id_disc'] . ">
                                        " . $row['nome_disc'] . "</option>";
                            //echo $row['id_disc'] . " - " . $row['nome_disc'];
                        }

                        ?>
                    </select>

                    <hr>
                    <div class="row mt-4">
                        <div class="col text-center">
                            <button class="btn btn-lg btn-success" type="submit">
                                <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-check-lg" viewBox="0 0 16 16">
                                    <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                </svg>
                                Salvar
                            </button>
                        </div>

                        <div class="col text-center">
                            <button type="reset" class="btn btn-warning btn-lg">
                                <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-eraser-fill" viewBox="0 0 16 16">
                                    <path d="M8.086 2.207a2 2 0 0 1 2.828 0l3.879 3.879a2 2 0 0 1 0 2.828l-5.5 5.5A2 2 0 0 1 7.879 15H5.12a2 2 0 0 1-1.414-.586l-2.5-2.5a2 2 0 0 1 0-2.828l6.879-6.879zm.66 11.34L3.453 8.254 1.914 9.793a1 1 0 0 0 0 1.414l2.5 2.5a1 1 0 0 0 .707.293H7.88a1 1 0 0 0 .707-.293l.16-.16z" />
                                </svg>
                                Apagar
                            </button>
                        </div>
                        <div class="col text-center">
                            <a class="btn btn-danger btn-lg" href="index.php" role="button">
                                <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
                                    <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                                    <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z" />
                                </svg>
                                Cancelar
                            </a>
                        </div>
                    </div>
                </div>
            </form>

            <br>

            <?php
            if (isset($_SESSION["result"])) {
                if ($_SESSION["result"]) {
                    //inseriu certo
            ?>
                    <div class="alert alert-success alertas" role="alert">
                        <h4 class="alert-heading"> Sucesso! </h4>
                        <p>Dados gravados corretamente.</p>
                    </div>
                <?php
                } else {
                    //não inseriu deu erro
                    $erro = $_SESSION["erro"];
                    unset($_SESSION["erro"]);
                ?>
                    <div class="alert alert-danger alertas" role="alert">
                        <h4 class="alert-heading"> Falha ao efetuar gravação.</h4>
                        <p> Erro: <?= $erro ?> </p>
                    </div>

            <?php

                }
                unset($_SESSION["result"]);
            }
            ?>
        </div>
        <div class="flex-fill">
            <?php
            require "ranking.php";
            ?>
        </div>
    </div>
</main>


<?php
require "footer.php";
?>