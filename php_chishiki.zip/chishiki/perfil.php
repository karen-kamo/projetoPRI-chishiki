<?php
session_start();
require("logica-autenticacao.php");
if (!autenticado()) {
    $_SESSION["restrito"] = true;
    redireciona(("protecao.php"));
    die();
}

require "header.php";

require "conexao.php";

$id = $_SESSION["usuario_id"];

//Coisas para aparecer só no aluno
$sql = "select pont_alu
FROM aluno 
where id_alu = ?";

try {
    $stmt = $conn->prepare($sql);
    $result = $stmt->execute([$id]);
    $pontuacao = $stmt->fetch();
} catch (Exception $e) {
    $result = false;
    $error = $e->getMessage();
}

//Coisas para aparecer só no professor
$sql = "select disciplina_prof
FROM professor 
where id_prof = ?";

try {
    $stmt = $conn->prepare($sql);
    $result = $stmt->execute([$id]);
    $prof = $stmt->fetch();
} catch (Exception $e) {
    $result = false;
    $error = $e->getMessage();
}
?>

<main>
    <div class="d-flex">
        <div>
            <div class="caixa-perfil">
                <h3 class="text-center titulo-formperg"> Dados do usuário </h3> <br>


                <div class="campos-perfil">
                    <label for="nome_usuario"> Nome do usuário </label>
                    <input class="form-control" type="text" id="nome_usuario" value="<?= ucwords(strtolower($_SESSION["usuario_nome"])) ?>" aria-label="Disabled input example" disabled readonly>
                </div>
                <div class="campos-perfil">
                    <label for="email_usuario"> E-mail do usuário </label>
                    <input class="form-control" type="text" id="email_usuario" value="<?= strtolower($_SESSION["usuario_email"]) ?>" aria-label="Disabled input example" disabled readonly>
                </div>
                <?php
                if (isProf()) {
                ?>
                    <div class="campos-perfil">
                        <label for="tipo_usuario"> Tipo de usuário </label>
                        <input class="form-control" type="text" id="tipo_usuario" value="Professor" aria-label="Disabled input example" disabled readonly>
                    </div>

                    <div class="campos-perfil">
                        <label for="disc_prof"> Disciplina </label>
                        <input class="form-control" type="text" id="disc_prof" value="<?= ucfirst(strtolower($prof["disciplina_prof"])) ?>" aria-label="Disabled input example" disabled readonly>
                    </div>
                <?php
                } else {
                ?>
                    <div class="campos-perfil">
                        <label for="tipo_usuario"> Tipo de usuário </label>
                        <input class="form-control" type="text" id="tipo_usuario" value="Aluno" aria-label="Disabled input example" disabled readonly>
                    </div>

                    <div class="campos-perfil">
                        <label for="aluno_pont"> Pontuação </label>
                        <input class="form-control" type="text" id="aluno_pont" value="<?= $pontuacao["pont_alu"] ?>" aria-label="Disabled input example" disabled readonly>
                    </div>
                <?php
                }
                ?>


                <div class="alert alert-danger text-center" role="alert">
                    Caso queira alterar alguns dos dados, vá para o programa desktop!
                </div>
            </div>

        </div>
        <div class="flex-fill">
            <?php
            require "ranking.php";
            ?>
        </div>

    </div>
</main>


<?php
require "footer.php";
?>
?>