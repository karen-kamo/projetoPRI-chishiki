<?php
session_start();
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="dist/bootstrap.min.css" rel="stylesheet">
    <title>Login</title>
    <link rel="stylesheet" href="estilo.css">
    <style>
        /* Login */
        body {
            background-color: #e2b3fc;
        }

        .caixa-login {
            text-align: center;
            width: 30em;
            border-radius: 5px;
            border: 5px inset #674B80;
            background-color: #a37cf2;
            margin: 5em 0 0 33em;
        }

        .titulo-login {
            background-color: #3e0b5c;
            margin-bottom: 1em;
            padding: 0.7em;
            color: white;
            font-weight: bold;
        }

        .frase {
            color: white;
            font-size: 1.5em;
            font-weight: bold;
            text-decoration: overline;
        }
    </style>
</head>

<body>

    <div class="caixa-login text-center">
        <h1 class="titulo-login">LOGIN</h1>
        <div class="m-3 frase">
            <p>Por favor, identifique-se</p>
        </div>
        <form action="login-alu.php" method="POST">
            <div class="form-floating m-3">
                <input type="email" class="form-control" id="email_alu" name="email_alu" placeholder="name@example.com" required>
                <label for="email_alu">E-mail</label>
            </div>
            <div class="form-floating m-3">
                <input type="password" class="form-control" id="senha_alu" name="senha_alu" placeholder="Password" required>
                <label for="senha_alu">Senha</label>
            </div>

            <div class="row m-4">
                <div class="col">

                    <button class="btn btn-lg btn-success" type="submit">
                        <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-door-open" viewBox="0 0 16 16">
                            <path d="M8.5 10c-.276 0-.5-.448-.5-1s.224-1 .5-1 .5.448.5 1-.224 1-.5 1z" />
                            <path d="M10.828.122A.5.5 0 0 1 11 .5V1h.5A1.5 1.5 0 0 1 13 2.5V15h1.5a.5.5 0 0 1 0 1h-13a.5.5 0 0 1 0-1H3V1.5a.5.5 0 0 1 .43-.495l7-1a.5.5 0 0 1 .398.117zM11.5 2H11v13h1V2.5a.5.5 0 0 0-.5-.5zM4 1.934V15h6V1.077l-6 .857z" />
                        </svg>
                        Entrar
                    </button>

                </div>
                <div class="col">
                    <a class="btn btn-danger btn-lg" href="index.php" role="button">
                        <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
                            <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                            <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z" />
                        </svg>
                        Cancelar
                    </a>

                </div>
            </div>
        </form>
    </div>

    <br>
    <div class="row justify-content-md-center">
        <div class="col-6">
            <?php
            if (isset($_SESSION["usuario_result"])) {
                if ($_SESSION["usuario_result"]) {
            ?>
                    <div class="alert alert-success" role="alert">
                        <h4 class="alert-heading">Sucesso!</h4>
                        <p>Aluno já está autenticado.</p>
                    </div>
                <?php

                } else {
                    $erro = $_SESSION["erro"];
                    unset($_SESSION["erro"]);
                ?>
                    <div class="alert alert-danger" role="alert">
                        <h4 class="alert-heading">Erro.</h4>
                        <p><?= $erro ?></p>
                    </div>
            <?php
                    unset($_SESSION["usuario_result"]);
                }
            }
            ?>
        </div>
    </div>


</body>

</html>